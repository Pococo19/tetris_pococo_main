#include "include\block.h"

Positioning::Positioning(int row, int cols)
{
    this->row = row;
    this->cols = cols;
}
